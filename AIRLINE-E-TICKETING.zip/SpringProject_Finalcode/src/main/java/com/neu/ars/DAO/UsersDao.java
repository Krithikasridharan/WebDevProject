package com.neu.ars.DAO;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.ars.pojo.Address;
import com.neu.ars.pojo.FlightInventory;
import com.neu.ars.pojo.Role;
import com.neu.ars.pojo.Routine;
import com.neu.ars.pojo.Users;

public class UsersDao extends DAO{
	
	public Users insertFlights(String userName, String password,
			Long contactNumber, String firstName,String lastName,
			Integer age,String favouriteDestination,Integer flatNo,String homeAirport,String streetName,String eMail,String gender) throws Exception {

		System.out.println(userName);
		
		try {
			  Session session=getSession();

			  Transaction tx=session.beginTransaction();
			  
			  
			  
			  Address add=new Address();
			  add.setFlatNo(flatNo);
			  add.setStreetName(streetName);

			  
			  Users users=new Users();
			  
			  
			  users.setUserName(userName);
			
			  users.setPassword(password);
			  users.setContactNumber(contactNumber);
			  users.setFirstName(firstName);
			  users.setLastName(lastName);
			  users.setAge(age);
			  users.setFavouriteDestination(favouriteDestination);
			  users.setEmail(eMail);
			  users.setHomeAirport(homeAirport);
			  users.setGender(gender);
			  users.setEnabled(1);
			  users.getAdd().add(add);
			  
			  Role role=new Role();
			  role.setRole("ROLE_USER");
			 role.setUserName(users.getUserName());
			 //role.setRoleId(users);
			  
			  session.persist(add);
				session.persist(users);
				tx.commit();
				
				System.out.println("\n\n Flights Added \n");
				return users;

			} catch (HibernateException e) {
				throw new Exception("Could not insert " , e);
			}
			finally{
				  
				  getSession().close();
		}

		
	
	}
	
	

}



