package com.neu.ars.pojo;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="Address")

public class Address {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ADDRESS_ID", unique=true, nullable=false)
	private Integer addressId;
    @Column(name="FLATNO", nullable=false)
private Integer flatNo;
    @Column(name="STREETNAME", nullable=false, length=50)
private String streetName;
    
   //@OneToOne
	//@PrimaryKeyJoinColumn
	@ManyToMany( mappedBy = "add",fetch=FetchType.LAZY)
	private Set<Person> persons = new HashSet<Person>();
	
	
	
	public Set<Person> getPersons() {
		return persons;
	}

	public void setPersons(Set<Person> persons) {
		this.persons = persons;
	}

	public Integer getId() {
		return addressId;
	}

	public void setId(Integer id) {
		this.addressId = id;
	}

	public Integer getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(Integer flatNo) {
		this.flatNo = flatNo;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	

	
    
    
    
    
}
