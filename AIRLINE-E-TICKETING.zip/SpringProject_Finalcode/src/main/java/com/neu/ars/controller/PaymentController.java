package com.neu.ars.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.neu.ars.DAO.TicketReservationDao;
import com.neu.ars.pojo.Payment;
import com.neu.ars.pojo.TicketReservation;

@Controller
public class PaymentController {

	@Autowired
	@Qualifier("paymentValidator")
	private Validator validator3;

	@Autowired
	private TicketReservationDao ticketReservationDao;

	@InitBinder("paydata")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator3);
	}

	@RequestMapping("pay")
	public String paymentPage(Model model, @RequestParam Long flightOne,
			@RequestParam Double priceForOneWay,
			@RequestParam String classType, @RequestParam String endTime,
			@RequestParam String arrivalDate,
			@RequestParam Integer total_Amount, @RequestParam Integer noOfSeats, @RequestParam String startTime,@RequestParam String endAirport,@RequestParam String startAirport, String departureDate) {

		Payment payment = new Payment();

		model.addAttribute("payment", payment);

		model.addAttribute("one", flightOne);
		model.addAttribute("oneWayPrice", priceForOneWay);
		model.addAttribute("typeOfClass", classType);
		model.addAttribute("time", endTime);
		model.addAttribute("destnDate", arrivalDate);
		model.addAttribute("fullAmt", total_Amount);
		model.addAttribute("ttlSeats", noOfSeats);
		
		model.addAttribute("startTime", startTime);
		model.addAttribute("endAirport", endAirport);
		model.addAttribute("startAirport", startAirport);
		model.addAttribute("departureDate", departureDate);
		
		
		

		return "payHere";

	}

	@RequestMapping("con")
	public ModelAndView confirmPayment(Model model,

	@Validated Payment payment, @RequestParam Long flightOne,
			@RequestParam Double priceForOneWay,
			@RequestParam String classType, @RequestParam String endTime,
			@RequestParam String arrivalDate,
			@RequestParam Integer total_Amount,
			@RequestParam Integer noOfSeats,@RequestParam String startTime,@RequestParam String endAirport,@RequestParam String startAirport, String departureDate,BindingResult result) {

		System.out.println(payment.getCardDetails());

		if (result.hasErrors()) {

			ModelAndView m1 = null;

			m1 = new ModelAndView("payHere");

			m1.addObject("payment", payment);

			return m1;

		} else {

			
	  try{
			  
			
			  
			Object o= ticketReservationDao.reserveTicket(arrivalDate, endTime, flightOne, total_Amount, payment.getCardDetails(), payment.getPaymentType(), startTime,endAirport,startAirport,departureDate, noOfSeats,classType );
			 
			  if (o != null) {
			  
		
			 
			 model.addAttribute("flight", o);
			 
		TicketReservation t = ticketReservationDao.bookingref(departureDate,endAirport);
			System.out.println("bookingg reff" + t.getBooking_ref());
		model.addAttribute("bookingref", t);
			  
			  }
	  }catch (Exception e) {
			  
			  // TODO Auto-generated catch block
			  
			  e.printStackTrace();
			  
			  }
			 
		

		}
		
		return new ModelAndView("finalPage");


	}

}
