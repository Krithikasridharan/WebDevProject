package com.neu.ars.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.FlightClass;
import com.neu.ars.pojo.FlightInventory;

public class FlightClassValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return FlightClass.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		FlightClass flightClass=(FlightClass) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "noOfSeats", "validate.noOfSeats","noOfSeats cannot be null");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "price", "validate.price","price cannot be null");

		
		
		
	}

}
