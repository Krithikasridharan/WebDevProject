package com.neu.ars.Validator;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.Payment;



public class PaymentValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Payment.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		Payment payment = (Payment) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardDetails",
				"validate.cardDetails", "Card No Is Invalid");
		
		if(payment.getCardDetails()!=null){
		if(payment.getCardDetails().length()<16)
		{
			errors.rejectValue("cardDetails","validate.cardDetails","it shd be of length 16");
		}

	}}

}
