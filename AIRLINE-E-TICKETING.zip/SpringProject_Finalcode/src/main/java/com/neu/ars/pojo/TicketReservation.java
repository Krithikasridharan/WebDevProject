package com.neu.ars.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="TicketReservation")
public class TicketReservation {

	
	@Id
	@Column(name="BOOKING_REFERENCE", unique=true, nullable=false, length = 10)
	private String booking_ref;
	
	
	@ManyToOne(fetch = FetchType.EAGER , cascade=CascadeType.ALL)
	@JoinColumn(name="FLIGHT_ID" , nullable=true)
	private FlightInventory flight;

	@Column(name = "DEPARTURE_DATE", nullable = false, length = 50)
	private String departureDate;

	@Column(name = "ARRIVAL_DATE", nullable = false, length = 50)
	private String arrivalDate;
	
	@Column(name = "START_TIME", nullable = false, length = 50)
	private String startTime;
	
	@Column(name = "END_TIME", nullable = false, length = 50)
	private String endTime;
	
	@Column(name = "BOOKING_DATE", nullable = false, length = 50)
	private String bookingDate;
	
	@Column(name="TOTAL_AMOUNT",nullable=false)
	private Integer total_Amount;
	
	@Column(name="NO_OF_SEATS", nullable=false)
	private Integer noOfSeats;
	
	@Column(name="Trip_Type", nullable=false)
	private String tripType;
	
	@Column(name="ONE_WAY_FLIGHT", nullable=true)
	private Long flightOne;
	
	@Column(name="PRICE_FOR_ONE_WAY", nullable=true)
	private Double priceForOneWay;
	
	@Column(name="PRICE_ROUND_TRIP", nullable=true)
	private Double priceForRoundTrip;
	
	@Column(name="TWO_WAY_FLIGHT", nullable=true)
	private Long flightTwo;
	
	
	
	@Column(name="Start_Airport", nullable=false)
	private String startAirport;
	
	@Column(name="End_Airport", nullable=false)
	private String endAirport;
	
	
	@Column(name="classType", nullable=false)
	private String classType;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TICKET_PAYMENT")
	private Payment payment;
	
	

	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ID")
	private Users id;
	
	
	

	

	public Long getFlightOne() {
		return flightOne;
	}

	public void setFlightOne(Long flightOne) {
		this.flightOne = flightOne;
	}

	public Double getPriceForOneWay() {
		return priceForOneWay;
	}

	public void setPriceForOneWay(Double priceForOneWay) {
		this.priceForOneWay = priceForOneWay;
	}

	public Double getPriceForRoundTrip() {
		return priceForRoundTrip;
	}

	public void setPriceForRoundTrip(Double priceForRoundTrip) {
		this.priceForRoundTrip = priceForRoundTrip;
	}

	public Long getFlightTwo() {
		return flightTwo;
	}

	public void setFlightTwo(Long flightTwo) {
		this.flightTwo = flightTwo;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public String getTripType() {
		return tripType;
	}

	public void setTripType(String tripType) {
		this.tripType = tripType;
	}

	public Users getId() {
		return id;
	}

	public void setId(Users id) {
		this.id = id;
	}

	public String getBooking_ref() {
		return booking_ref;
	}

	public void setBooking_ref(String booking_ref) {
		this.booking_ref = booking_ref;
	}

	

	public FlightInventory getFlight() {
		return flight;
	}

	public void setFlight(FlightInventory flight) {
		this.flight = flight;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Integer getTotal_Amount() {
		return total_Amount;
	}

	public void setTotal_Amount(Integer total_Amount) {
		this.total_Amount = total_Amount;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public Integer getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public String getStartAirport() {
		return startAirport;
	}

	public void setStartAirport(String startAirport) {
		this.startAirport = startAirport;
	}

	public String getEndAirport() {
		return endAirport;
	}

	public void setEndAirport(String endAirport) {
		this.endAirport = endAirport;
	}

	
	

	

}
