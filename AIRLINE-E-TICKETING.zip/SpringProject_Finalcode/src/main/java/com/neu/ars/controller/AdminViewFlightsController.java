package com.neu.ars.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.neu.ars.DAO.FlightScheduleDao;
import com.neu.ars.DAO.PersonDetailsDao;
import com.neu.ars.pojo.Routine;
import com.neu.ars.pojo.Users;


@Controller
public class AdminViewFlightsController {
	private static final Logger Logger = LoggerFactory
			.getLogger(HomeController.class);
	@Autowired
	@Qualifier("routineValidator")
	private Validator validator;

	@Autowired
	private FlightScheduleDao flightScheduleDao;

	@InitBinder("searchFlightsBySchedule")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@RequestMapping("viewFlightsBySchedule")
	public ModelAndView searchUsers(Model m) {
		ModelAndView mod=new ModelAndView("adminViewingFlightsBySchedule");

		Routine routine = new Routine();
		
		mod.addObject("routine",routine);

		return mod;

	}

	@RequestMapping(value="flights", method=RequestMethod.POST)
	public String viewUsersDetails(Model model,@Validated Routine routine, BindingResult result
			) {

		if (result.hasErrors()) {

			model.addAttribute("routine", routine);
			return "adminViewingFlightsSchedule";
		}

		else {
			try {

				Routine r=flightScheduleDao.searchFlightsBySchedule(routine.getS_id());
				
				//Users p = (Users) flightScheduleDao.searchPerson(user.getId());

				if (r != null) {

					model.addAttribute("routine", r);
					//model.addAttribute("items", p.getAdd());

					//System.out.println(p.getAdd());

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "fightsByScheduleResult";
		}

	}
	
	
}
