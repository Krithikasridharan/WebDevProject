package com.neu.ars.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Routine")
public class Routine {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="S_ID", unique=true, nullable=false)
	private Integer s_id;
	
	@Column(name = "DEPARTURE_DATE", nullable = false, length = 50)
	private String departureDate;

	@Column(name = "ARRIVAL_DATE", nullable = false, length = 50)
	private String arrivalDate;
	
	@Column(name = "START_TIME", nullable = false, length = 50)
	private String startTime;
	
	@Column(name = "END_TIME", nullable = false, length = 50)
	private String endTime;
	
	@ManyToOne(fetch = FetchType.EAGER , cascade=CascadeType.ALL)
	@JoinColumn(name="FLIGHT_ID" , nullable=false)
	private FlightInventory flight;
	
	@OneToMany(fetch=FetchType.EAGER , mappedBy="routine" , cascade=CascadeType.ALL)
	private List<FlightClass> routine = new ArrayList<FlightClass>();

	public Integer getS_id() {
		return s_id;
	}

	public void setS_id(Integer s_id) {
		this.s_id = s_id;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public FlightInventory getFlight() {
		return flight;
	}

	public void setFlight(FlightInventory flight) {
		this.flight = flight;
	}

	public List<FlightClass> getRoutine() {
		return routine;
	}

	public void setRoutine(List<FlightClass> routine) {
		this.routine = routine;
	}

	
	}
