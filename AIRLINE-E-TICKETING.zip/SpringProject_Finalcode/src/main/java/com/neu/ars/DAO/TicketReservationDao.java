package com.neu.ars.DAO;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.ars.pojo.Address;
import com.neu.ars.pojo.Payment;
import com.neu.ars.pojo.Person;
import com.neu.ars.pojo.TicketReservation;
import com.neu.ars.pojo.Users;

public class TicketReservationDao extends DAO{
	
	public Object reserveTicket(String arrivalDate,String endTime,

			 Long flightOne, Integer total_Amount,String cardDetails,String paymentType, String startTime, String endAirport, String startAirport, String departureDate, Integer noOfSeats, String classType) throws Exception {

			try {

			Session session = getSession();

			Transaction t = session.beginTransaction();

			
			
			Users u= new Users();
			u.setFirstName("uu");
			
			u.setAge(65);
			u.setContactNumber(789765345);
			u.setEmail("uu@gmail.com");
			u.setFavouriteDestination("mal");
		
			u.setLastName("hjk");
			u.setGender("f");
			u.setHomeAirport("booa");
			u.setPassword("9097");
			//u.setRole("user");
			u.setMembership_id(987600);
			u.setUserName("uu");
			
			Address add = new Address();

			add.setFlatNo(8900);
			add.setStreetName("hjkk");
			u.getAdd().add(add);
			
			
			Payment pay=new Payment();
			pay.setCardDetails(cardDetails);
			pay.setPaymentType(paymentType);
			pay.setTransaction_Date("04/22/2015");
			pay.setStatus("paid");

			
			TicketReservation ticket=new TicketReservation();

			ticket.setArrivalDate(arrivalDate);
			ticket.setEndTime(endTime);
			ticket.setTotal_Amount(total_Amount);
			ticket.setTripType("oneway");
			ticket.setEndAirport(endAirport);
			ticket.setFlightOne(flightOne);
			ticket.setBooking_ref("TUR457");
			ticket.setBookingDate("09/25/2015");
			ticket.setStartTime(startTime);
			ticket.setEndAirport(endAirport);
			ticket.setStartAirport(startAirport);
			ticket.setDepartureDate(departureDate);
			ticket.setNoOfSeats(noOfSeats);
			ticket.setClassType(classType);

			

			session.persist(add);

			session.persist(u);

			session.persist(pay);

			session.persist(ticket);

			t.commit();

			System.out.println("\n\n booking Details inserted to db \n");

			return u ;

			} catch (HibernateException e) {

			// rollback();

			throw new Exception("Could not insert " + e.getMessage());

			}

			finally {

			// getSession().flush();

			getSession().close();

			}

			}
	
	
public TicketReservation bookingref(String departureDate, String endAirport) throws Exception {
		
		
		try {
			// begin();
			Query q =getSession().createQuery(
					"from TicketReservation where departureDate=:departureDate and endAirport=:endAirport");
			q.setString("departureDate", departureDate);
			q.setString("endAirport", endAirport);
			
			//q.setInteger("id", id);
			TicketReservation f = (TicketReservation) q.uniqueResult();
			
			System.out.println("inside dao " + f.getBooking_ref());
			

			//List <Person>usersList =  q.list();

		return f;

		} catch (HibernateException e) {
			throw new Exception("Could not get user " + departureDate, e);
		}
	}
}
	


	
	
	

