package com.neu.ars.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.Routine;

public class RoutineValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Routine.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		Routine routine=(Routine) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "s_id", "validate.s_id","s_id cannot be null");

	    /*
	     
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "arrivalDate", "validate.arrivalDate","arrivalDate cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startTime", "validate.startTime","startTime cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "endTime", "validate.endTime","endTime cannot be null");
		
		if(routine.getArrivalDate().equals(0))
		{
		errors.rejectValue("arrivalDate", "validate.arrivalDate", "shd not be zero");
		}
		if(routine.getDepartureDate().equals(0))
		{
		errors.rejectValue("departureDate", "validate.departureDate", "shd not be zero");
		}

		if(routine.getStartTime().equals(0))
		{
		errors.rejectValue("startTime", "validate.startTime", "shd not be zero");
		}
		
		if(routine.getEndTime().equals(0))
		{
		errors.rejectValue("endTime", "validate.endTime", "shd not be zero");
		}
		if(routine.getS_id().
		
*/		
		if(!routine.getS_id().equals(0)) {
			
		errors.rejectValue("s_id", "validate.s_id", "shd not be zero");

	}
	}
}
