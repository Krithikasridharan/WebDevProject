package com.neu.ars.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

import org.springframework.stereotype.Repository;

@Repository
@Entity
@Inheritance(strategy=InheritanceType.JOINED)
@Table(name = "Person")
public class Person {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id;
	@Column(name = "FNAME", nullable = false, length = 50)
	private String firstName;
	@Column(name = "LNAME", nullable = false, length = 50)
	private String lastName;
	@Column(name = "PHONE", nullable = false, length = 50)
	private long contactNumber;
	@Column(name = "EMAIL", nullable = false, length = 50)
	private String email;
	@Column(name = "GENDER", nullable = false, length = 10)
	private String gender;
	
	@Column(name = "USERNAME", unique = true, nullable = false, length = 50)
	private String userName;
	@Column(name = "PASSWORD", nullable = false, length = 50)
	private String password;
	@Column(name = "AGE", nullable = false)
	private Integer age;
	@Column(name = "ENABLED", columnDefinition = "TINYINT(1) DEFAULT 0")
	private int enabled;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "person")
	private Set<Role> role = new HashSet<Role>();

	//@OneToOne(fetch = FetchType.EAGER, mappedBy = "person", cascade = CascadeType.ALL)
	
	//private Address address;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "USERS_ADDRESS", joinColumns = { 
			@JoinColumn(name = "ID") }, 
			inverseJoinColumns = { @JoinColumn(name = "ADDRESS_ID") })
	private Set<Address> add = new HashSet<Address>();
	
	

	
	

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public void setRole(Set<Role> role) {
		this.role = role;
	}

	public Set<Address> getAdd() {
		return add;
	}

	public void setAdd(Set<Address> add) {
		this.add = add;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

}
