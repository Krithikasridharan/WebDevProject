package com.neu.ars.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Payment")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer payment_id;
	
	@Column(name = "STATUS", nullable = false, length=25)
	private String status;
	
	@Column(name = "TRANSACTION_DATE", nullable = false,length=25)
	private String transaction_Date;
	
	@Column(name = "PAYMENT_TYPE", nullable = true,length=25)
	private String paymentType;
	
	@Column(name = "CARD_DETAILS", unique = true, nullable = true,length=16)
	private String cardDetails;
	
	
	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getCardDetails() {
		return cardDetails;
	}

	public void setCardDetails(String cardDetails) {
		this.cardDetails = cardDetails;
	}

	public Integer getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(Integer payment_id) {
		this.payment_id = payment_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransaction_Date() {
		return transaction_Date;
	}

	public void setTransaction_Date(String transaction_Date) {
		this.transaction_Date = transaction_Date;
	}

	




}
