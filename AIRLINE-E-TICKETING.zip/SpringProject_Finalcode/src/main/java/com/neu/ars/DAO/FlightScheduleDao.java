package com.neu.ars.DAO;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.ars.pojo.Routine;

public class FlightScheduleDao extends DAO{

public Routine searchFlightsBySchedule(Integer s_id) throws Exception {
		
		
		try {
			// begin();
			Query q =getSession().createQuery(
					"from Routine where s_id=:s_id");
			q.setString("s_id", String.valueOf(s_id));
			//q.setInteger("id", id);
			
			Routine routine=(Routine) q.uniqueResult();
			
			

			//List <Person>usersList =  q.list();

		return routine;

		} catch (HibernateException e) {
			throw new Exception("Could not get user " + s_id, e);
		}
	}

	

public Routine searchWithDeparDate(String departureDate)throws Exception
{
	
	try {
		// begin();
		Query q =getSession().createQuery(
				"from Routine where departureDate=:departureDate");
		q.setString("departureDate", departureDate);
		//q.setInteger("id", id);
		
		Routine routine=(Routine) q.uniqueResult();
		
		

		//List <Person>usersList =  q.list();

	return routine;

	} catch (HibernateException e) {
		throw new Exception("Could not get user " + departureDate, e);
	}
}

	
	
	
	
	
	
	
	
	
}

	

