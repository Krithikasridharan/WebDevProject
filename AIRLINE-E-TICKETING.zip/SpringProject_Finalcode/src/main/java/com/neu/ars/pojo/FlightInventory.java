package com.neu.ars.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="FlightInventory")
public class FlightInventory {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FLIGHT_ID", unique = true, nullable = false)
	private Long flightId;
	
	@Column(name = "AIRLINE", nullable = false, length = 50)
	private String airline;
	
	@Column(name = "START_AIRPORT", nullable = false, length = 50)
	private String startAirport;
	
	
	@Column(name = "END_AIRPORT", nullable = false, length = 50)
	private String endAirport;
	
	
	
	@OneToMany(fetch=FetchType.EAGER , mappedBy="flight" , cascade=CascadeType.ALL)

	private List<Routine> routine = new ArrayList<Routine>();
	
	
	@OneToMany(fetch=FetchType.EAGER , mappedBy="flight" , cascade=CascadeType.ALL)

	private List<TicketReservation> ticketreservation = new ArrayList<TicketReservation>();

	
	
	
	
	
	

	



	public List<TicketReservation> getTicketreservation() {
		return ticketreservation;
	}



	public void setTicketreservation(List<TicketReservation> ticketreservation) {
		this.ticketreservation = ticketreservation;
	}



	public Long getFlightId() {
		return flightId;
	}



	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}



	public String getAirline() {
		return airline;
	}



	public void setAirline(String airline) {
		this.airline = airline;
	}



	public String getStartAirport() {
		return startAirport;
	}



	public void setStartAirport(String startAirport) {
		this.startAirport = startAirport;
	}



	public String getEndAirport() {
		return endAirport;
	}



	public void setEndAirport(String endAirport) {
		this.endAirport = endAirport;
	}



	public List<Routine> getRoutine() {
		return routine;
	}



	public void setRoutine(List<Routine> routine) {
		this.routine = routine;
	}

	
}
