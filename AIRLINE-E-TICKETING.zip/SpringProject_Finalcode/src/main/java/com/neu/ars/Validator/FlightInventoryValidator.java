package com.neu.ars.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.FlightInventory;

public class FlightInventoryValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return FlightInventory.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		
		FlightInventory flightInventory=(FlightInventory) target;
		
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "flightId", "validate.flightId","Flight Id cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "airline", "validate.airline","airline cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startAirport", "validate.startAirport","startAirport cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "endAirport", "validate.endAirport","endAirport cannot be null");

	if(flightInventory.getFlightId().equals(0))
	{
		errors.rejectValue("flightId", "validate.flightId", "shd not be zero");
	}
	if(flightInventory.getAirline().equals(0))
		{
		errors.rejectValue("airline", "validate.airline", "shd not be zero");
		}

	if(flightInventory.getStartAirport().equals(0))
		{
		errors.rejectValue("startAirport", "validate.startAirport", "shd not be zero");
		}

	if(flightInventory.getEndAirport().equals(0))
		{
		errors.rejectValue("endAirport", "validate.endAirport", "shd not be zero");
		}
	

	if(!flightInventory.getEndAirport().isEmpty()) {
		if(!flightInventory.getEndAirport().matches("^[a-zA-Z]$"))
			errors.rejectValue("flightInventory", "the End airport is invalid", new Object[]{flightInventory.getEndAirport()}, "Only letters allowed");
	}

	if(!flightInventory.getStartAirport().isEmpty()) {
		if(!flightInventory.getStartAirport().matches("^[a-zA-Z]$"))
			errors.rejectValue("flightInventory", "the Start airport is invalid", new Object[]{flightInventory.getStartAirport()}, "Only letters allowed");
	}
	if(!flightInventory.getAirline().isEmpty()) {
		if(!flightInventory.getAirline().matches("^[a-zA-Z]$"))
			errors.rejectValue("flightInventory", "the  airline name is invalid", new Object[]{flightInventory.getAirline()}, "Only letters allowed");
	}

	
	
	}

}
