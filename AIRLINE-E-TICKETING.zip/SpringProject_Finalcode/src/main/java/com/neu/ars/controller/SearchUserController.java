package com.neu.ars.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.neu.ars.DAO.PersonDetailsDao;
import com.neu.ars.pojo.Users;

@Controller
public class SearchUserController {

	private static final Logger Logger = LoggerFactory
			.getLogger(HomeController.class);

	@Autowired
	@Qualifier("searchUserValidator")
	private Validator validator;

	@Autowired
	private PersonDetailsDao personDetailsDao;

	@InitBinder("searchUser")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@RequestMapping("searchUserDetails")
	public ModelAndView searchUsers(Model m) {
		ModelAndView mod=new ModelAndView("adminViewingUserDetails");

		Users users = new Users();
		
		mod.addObject("users",users);

		return mod;

	}

	@RequestMapping(value="userPersonalDetails", method=RequestMethod.POST)
	public String viewUsersDetails(Model model,@Validated Users user, BindingResult result
			) {

		if (result.hasErrors()) {

			model.addAttribute("user", user);
			return "adminViewingUserDetails";
		}

		else {
			try {

				Users p = (Users) personDetailsDao.searchPerson(user.getId());

				if (p != null) {

					model.addAttribute("id", p);
					model.addAttribute("items", p.getAdd());

					System.out.println(p.getAdd());

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "viewUsersById";
		}

	}
	
	
	
	
}
