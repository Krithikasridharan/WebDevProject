package com.neu.ars.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.TicketReservation;

public class TicketReservationValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return TicketReservation.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		

		TicketReservation ticketReservation=(TicketReservation) target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tripType", "validate.waytravel","waytravel cannot be null");
	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "departureDate", "validate.departureDate","departureDate cannot be null");
	//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "arrivalDate", "validate.returnDate","returnDate cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "noOfSeats", "validate.noOfPassengers","noOfPassengers cannot be null");
	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classType", "validate.Classpassenger","Classpassenger cannot be null");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "total_Amount", "validate.total_Amount","total_Amount cannot be null");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "noOfSeats", "validate.noOfSeats","noOfSeats cannot be null");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "tripType", "validate.tripType","tripType cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startAirport", "validate.startAirport","startAirport cannot be null");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "endAirport", "validate.endAirport","endAirport cannot be null");

		
		/*
		
		
	if(ticketReservation.getDepartureDate().equals(0))
	{
		errors.rejectValue("departureDate", "validate.departureDate", "shd not be zero");
	}
	
	
	if(ticketReservation.getArrivalDate().equals(0))
	{
		errors.rejectValue("arrivalDate", "validate.arrivalDate", "shd not be zero");
	}
	
	
	if(ticketReservation.getStartTime().equals(0))
	{
		errors.rejectValue("startTime", "validate.startTime", "shd not be zero");
	}
	
	
	if(ticketReservation.getEndTime().equals(0))
	{
		errors.rejectValue("endTime", "validate.endTime", "shd not be zero");
	}
	
	if(ticketReservation.getBookingDate().equals(0))
	{
		errors.rejectValue("bookingDate", "validate.total_Amount", "shd not be zero");
	}
	
	
	if(ticketReservation.getNoOfSeats().equals(0))
	{
		errors.rejectValue("noOfSeats", "validate.noOfSeats", "shd not be zero");
	}
	
	if(ticketReservation.getTripType().equals(0))
	{
		errors.rejectValue("tripType", "validate.tripType", "shd not be zero");
	}
	
	if(ticketReservation.getStartAirport().equals(0))
	{
		errors.rejectValue("startAirport", "validate.startAirport", "shd not be zero");
	}	
	
	if(ticketReservation.getEndAirport().equals(0))
	{
		errors.rejectValue("endAirport", "validate.endAirport", "shd not be zero");
	}	
	
	
	
	
	*/
	
	}

}
