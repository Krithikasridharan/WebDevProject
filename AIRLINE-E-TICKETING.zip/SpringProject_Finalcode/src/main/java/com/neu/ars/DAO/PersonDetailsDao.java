package com.neu.ars.DAO;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.ars.pojo.Person;
import com.neu.ars.pojo.Users;

public class PersonDetailsDao extends DAO {

	public Person searchPerson(Integer id) throws Exception {
		
		
		try {
			// begin();
			Query q =getSession().createQuery(
					"from Users where id=:id");
			q.setString("id", String.valueOf(id));
			//q.setInteger("id", id);
			Users p= (Users) q.uniqueResult();
			
			

			//List <Person>usersList =  q.list();

		return p;

		} catch (HibernateException e) {
			throw new Exception("Could not get user " + id, e);
		}
	}
}
	

