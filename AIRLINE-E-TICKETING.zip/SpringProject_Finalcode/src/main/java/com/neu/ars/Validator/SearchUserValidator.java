package com.neu.ars.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.ars.pojo.Users;

public class SearchUserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Users.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub

		Users users = (Users) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "validate.id",
				"please enter valid input");
		if (users.getId() < 1 || users.getId().equals(0)) {
			errors.rejectValue("id", "validate.id", "shd not be zero");
		}

	}

}
