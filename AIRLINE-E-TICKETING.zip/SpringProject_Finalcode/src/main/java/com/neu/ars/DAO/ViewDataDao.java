package com.neu.ars.DAO;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class ViewDataDao extends DAO{
	
	public List<String>getVenue(String startAirport) throws Exception
	{
		
		System.out.println(startAirport);
		
		try{
			Session s=getSession();
			Query q=s.createQuery("select fi.startAirport from FlightInventory fi where fi.startAirport like :startAirport");
			q.setString("startAirport", startAirport +"%");
			
			
			List<String> l= q.list();
			
			
			return l;
			
		}
		catch(HibernateException he)
		{
			throw new Exception("Could not get user " + startAirport, he);
		}
	}
		
		
		public List<String>getDestinationVenue(String endAirport) throws Exception
		{
			
			System.out.println(endAirport);
			
			try{
				Session s=getSession();
				Query q=s.createQuery("select fi.endAirport from FlightInventory fi where fi.endAirport like :endAirport");
				q.setString("endAirport", endAirport +"%");
				
				
				List<String> lv= q.list();
				
				
				return lv;
				
			}
			catch(HibernateException he)
			{
				throw new Exception("Could not get user " + endAirport, he);
			}
			
		
		
		
		
		
		
	}

}
