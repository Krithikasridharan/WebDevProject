package com.neu.ars.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.neu.ars.DAO.FlightDetailsDao;
import com.neu.ars.DAO.UsersDao;
import com.neu.ars.pojo.FlightInventory;
import com.neu.ars.pojo.Person;
import com.neu.ars.pojo.TicketReservation;
import com.neu.ars.pojo.Users;

@Controller
public class HomeController {
	@Autowired
	private FlightDetailsDao flightDetailsDao;	
	
	@Autowired
	private UsersDao usersDao;	
	
	

	@RequestMapping(value = { "/", "/welcome**" }, method = RequestMethod.GET)
	public ModelAndView defaultPage() {

		ModelAndView model = new ModelAndView();
		model.addObject("title",
				"Spring Security Login Form - Database Authentication");
		model.addObject("message", "This is default page!");
		model.setViewName("hello");
		return model;

	}

	@RequestMapping(value = "/admin**", method = RequestMethod.GET)
	public ModelAndView adminPage() {

		ModelAndView model = new ModelAndView();
		model.addObject("title",
				"Spring Security Login Form - Database Authentication");
		model.addObject("message", "This page is for ROLE_ADMIN only!");
		model.setViewName("admin");
		return model;

	}

	@RequestMapping(value = "/user/**", method = RequestMethod.GET)
	public ModelAndView admin1Page() throws ParseException {

		ModelAndView model = new ModelAndView();
		model.addObject("title",
				"Spring Security Login Form - Database Authentication");
		model.addObject("message", "This page is for ROLE_USER only!");
		
		
	TicketReservation ticketReservation =new TicketReservation();
	model.addObject("ticketReservation", ticketReservation)	;
	model.setViewName("searchFlights");
		return model;
		
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {

		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}

		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}
		model.setViewName("login");

		return model;

	}

	// for 403 access denied page
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {

		ModelAndView model = new ModelAndView();

		// check if user is login
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			model.addObject("username", userDetail.getUsername());
		}

		model.setViewName("403");
		return model;

	}
	
	@RequestMapping("addToFlightInventory")
	 public String addFlightsToInventory(@RequestParam("airline") String airline,
			 @RequestParam("end_airport") String end_airport,
				@RequestParam("start_airport") String start_airport,
				@RequestParam("departure_date") String departure_date,
				@RequestParam("arrival_date") String arrival_date,
				@RequestParam("end_time") String end_time,
				@RequestParam("start_time") String start_time,
				@RequestParam("class_type") String class_type,
				@RequestParam("no_of_seats") Integer no_of_seats,
				@RequestParam("price") Double price, Model model) {
		 try {
			 
			 
			 System.out.println(airline);
				FlightInventory fi = flightDetailsDao.insertFlights(airline, end_airport, start_airport,departure_date,arrival_date,end_time,start_time,class_type,no_of_seats,price);
						
				 System.out.println(fi.getAirline());

				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "flightsAddedConfirmation";
		}
	@RequestMapping("userRegistration")
	public String userReg(@RequestParam("userName") String userName,
			 @RequestParam("password") String password,
				@RequestParam("contactNumber") Long contactNumber,
				@RequestParam("firstName") String firstName,
				@RequestParam("lastName") String lastName,
				@RequestParam("age") Integer age,
				@RequestParam("favouriteDestination") String favouriteDestination,
				@RequestParam("flatNo") Integer flatNo,
				@RequestParam("homeAirport") String homeAirport,
				@RequestParam("streetName") String streetName,
				@RequestParam("eMail") String eMail,@RequestParam("gender") String gender,
				Model model){
					
		
		
		
 try {
			 
			 
			 System.out.println(userName);
				Users users = usersDao.insertFlights(userName, password, contactNumber,firstName,lastName,age,favouriteDestination,flatNo,homeAirport,streetName,eMail,gender);
						
System.out.println(users.getUserName());
				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		return "userAccountCreation";
		
		
		
		
		
		
	}

	
	 
	 
	
	
	
	@RequestMapping("addFlights")
	 public String addFlights(Model m)
	 {
		return "adminDashBoard";
		 
	 }
	 
	 
	 @RequestMapping("userSignUp")
	 public String signUp(Model m)
	 {
		return "userRegistrationForm";
		 
	 }
	 
	 @RequestMapping("home")
	 public String home(Model m)
	 {
		return "home";
		 
	 }
	 
	 
	 

}