package com.neu.ars.pojo;

import javax.persistence.Entity;
import javax.persistence.Table;


@Table(name="TicketCancellation")

public class TicketCancellation {

}
