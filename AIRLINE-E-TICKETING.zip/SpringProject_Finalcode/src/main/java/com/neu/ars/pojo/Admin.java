package com.neu.ars.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Admin")
public class Admin extends Person {
	@Column(name = "REQUEST", nullable = false, length = 50)
	private String request;

	@Column(name = "SHIFT", nullable = false, length = 50)
	private String shift;

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getShift() {
		return shift;
	}

	public void setShift(String shift) {
		this.shift = shift;
	}

}
