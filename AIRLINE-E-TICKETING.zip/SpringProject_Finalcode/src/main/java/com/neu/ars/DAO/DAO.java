package com.neu.ars.DAO;

import org.hibernate.Session;

public abstract class DAO {
	public Session getSession() {
		return HibernateUtil.getSessionFactory().openSession();
	}

	protected void begin() {
		getSession().beginTransaction();
	}

	protected void commit() {
		getSession().getTransaction().commit();
	}

	protected void rollback() {
		getSession().getTransaction().rollback();
	}

	public void close() {
		getSession().close();
	}
}
