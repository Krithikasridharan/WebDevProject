package com.neu.ars.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class Users extends Person {
	
	
	@Column(name = "MEMBERSHIPID")
	private Integer membership_id;
	@Column(name = "HOMEAIRPORT", nullable = false, length = 50)
	private String homeAirport;
	@Column(name = "FAVOURITEDESTINATION", nullable = false, length = 50)
	private String favouriteDestination;
	
	
	@OneToMany(fetch=FetchType.EAGER , mappedBy="id" , cascade=CascadeType.ALL)
	private List<TicketReservation> ticketReservationList = new ArrayList<TicketReservation>();


	public Integer getMembership_id() {
		return membership_id;
	}

	public void setMembership_id(Integer membership_id) {
		this.membership_id = membership_id;
	}

	public List<TicketReservation> getTicketReservationList() {
		return ticketReservationList;
	}

	public void setTicketReservationList(
			List<TicketReservation> ticketReservationList) {
		this.ticketReservationList = ticketReservationList;
	}

	public String getHomeAirport() {
		return homeAirport;
	}

	public void setHomeAirport(String homeAirport) {
		this.homeAirport = homeAirport;
	}

	public String getFavouriteDestination() {
		return favouriteDestination;
	}

	public void setFavouriteDestination(String favouriteDestination) {
		this.favouriteDestination = favouriteDestination;
	}

}
