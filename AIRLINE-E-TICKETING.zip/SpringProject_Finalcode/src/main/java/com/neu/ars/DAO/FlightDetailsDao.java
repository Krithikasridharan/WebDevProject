package com.neu.ars.DAO;



import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.ars.pojo.FlightClass;
import com.neu.ars.pojo.FlightInventory;
import com.neu.ars.pojo.Routine;

public class FlightDetailsDao extends DAO{
	public FlightInventory insertFlights(String airline, String end_airport,
			String start_airport, String departure_date,String arrival_date,
			String end_time,String start_time,String class_type,Integer no_of_seats,Double price) throws Exception {

		System.out.println(airline);

		try {
			  Session session=getSession();

			  Transaction tx=session.beginTransaction();
			  
			FlightInventory fi = new FlightInventory();
			
			fi.setAirline(airline);
			fi.setEndAirport(end_airport);
			fi.setStartAirport(start_airport);
			
			System.out.println(fi.getEndAirport());
			
			Routine r=new Routine();
			r.setDepartureDate(departure_date);
			r.setArrivalDate(arrival_date);
			r.setEndTime(end_time);
			r.setStartTime(start_time);
			r.setFlight(fi);
			
			FlightClass fc=new FlightClass();
			fc.setClassType(class_type);
			fc.setNoOfSeats(no_of_seats);
			fc.setPrice(price);
			fc.setRoutine(r);
			

			session.persist(fi);
			session.persist(r);
			session.persist(fc);
			tx.commit();
			
			System.out.println("\n\n Flights Added \n");
			return fi;

		} catch (HibernateException e) {
			throw new Exception("Could not insert " , e);
		}
		finally{
			  
			  getSession().close();
	}
	}
	

	public List searchFlight(String tripType,String startAirport,String endAirport,String departureDate,String classType,Integer noOfSeats)
	 throws Exception {

		//System.out.println("ok");


		try {

		// begin();

		Session session =getSession();

		Query q = session.

		createQuery ("select fi.flightId,fi.airline,fi.startAirport,fi.endAirport,r.departureDate,r.endTime, r.startTime,fc.noOfSeats,fc.classType,fc.price from FlightInventory fi inner join fi.routine r inner join r.routine fc where  fi.startAirport=:startAirport and fi.endAirport=:endAirport and fc.classType=:classType and fc.noOfSeats>=:noOfSeats and r.departureDate=:departureDate");

				

		System.out.println("inside");

		
		q.setString("startAirport",startAirport);
		q.setString("endAirport",endAirport);
		q.setString("departureDate",departureDate);
		q.setString("classType",classType);

		q.setString("noOfSeats", String.valueOf(noOfSeats));

		System.out.println(q);

		System.out.println("q value");

		List unique = q.list();

		System.out.println("list");

		//FlightDetails c = (FlightDetails) q;

		return unique;

		} catch (HibernateException e) {

		// rollback();

		throw new Exception("Could not get flightNumber " + noOfSeats + e.getMessage());

		}

		}









}

