package com.neu.ars.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.neu.ars.DAO.FlightDetailsDao;
import com.neu.ars.DAO.FlightScheduleDao;
import com.neu.ars.DAO.PersonDetailsDao;
import com.neu.ars.pojo.Payment;
import com.neu.ars.pojo.Routine;
import com.neu.ars.pojo.TicketReservation;
import com.neu.ars.pojo.Users;


@Controller
public class UserSearchingFlights {


	@Autowired
	@Qualifier("ticketReservationValidator")
	private Validator validator1;

	@Autowired
	private FlightDetailsDao flightDetailsDao;
	
	@Autowired
	private FlightScheduleDao flightScheduleDao;
	

	@InitBinder("ticketReservation")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator1);
	}
	
	private TicketReservation ticketReservation;
	 @RequestMapping("goToSearchFlights")
		public String searchFlights(Model m) {
		 
			TicketReservation ticketReservation = new TicketReservation();
			
m.addAttribute("ticketReservation",ticketReservation);
			return "searchFlights";

		}
	 
	 
	 @RequestMapping("searchResults1")
		public String searchRes(Model m, @Validated TicketReservation ticketReservation, BindingResult result) throws Exception {
		
		
		 
		 if(result.hasErrors()){
			 
			 m.addAttribute("ticketReservation",ticketReservation);	 
		
		 System.out.println("hhhh"+ ticketReservation);
		 return "searchFlights";
		 
		 }else{
			 
			try{
			
			 System.out.println("okkkkkkkllllhhhggg");
			 
			 System.out.println(ticketReservation.getTripType());
			 
			 System.out.println(ticketReservation.getStartAirport());
			 System.out.println(ticketReservation.getEndAirport());
			 System.out.println(ticketReservation.getDepartureDate());
			 System.out.println(ticketReservation.getClassType());
			 System.out.println(ticketReservation.getNoOfSeats());

			// System.out.println(ticketReservation.getTripType());


			List<Object[]>search=flightDetailsDao.searchFlight(ticketReservation.getTripType(),ticketReservation.getStartAirport(),
					ticketReservation.getEndAirport(),ticketReservation.getDepartureDate(),ticketReservation.getClassType(),ticketReservation.getNoOfSeats());
				this.ticketReservation=ticketReservation;
		
			if(search!= null){
				
			
				System.out.println("list lenght" + search.size());

				
				m.addAttribute("found", search);
			
			
			}
			}catch (Exception e){
				
				e.printStackTrace();
			}
			
			
		
		 return "searchResults";
		 
		 
	 

		 }
		 
		 
		
		 
		 
		 
		 
	 }
	 
	
	 @RequestMapping("confirm")
	 public String oneWaySel(Model model, @RequestParam Long flightnum,@RequestParam Double price) throws Exception{
		
		 
		 try{
			 
			Routine r=flightScheduleDao.searchWithDeparDate(ticketReservation.getDepartureDate());
		 
			ticketReservation.setArrivalDate(r.getArrivalDate());
			ticketReservation.setEndTime(r.getEndTime());
			ticketReservation.setStartTime(r.getStartTime());
			
			ticketReservation.setEndAirport(ticketReservation.getEndAirport());
			ticketReservation.setStartAirport(ticketReservation.getStartAirport());
			ticketReservation.setClassType(ticketReservation.getClassType());
			ticketReservation.setDepartureDate(ticketReservation.getDepartureDate());
			ticketReservation.setNoOfSeats(ticketReservation.getNoOfSeats());
		ticketReservation.setTripType(ticketReservation.getTripType());
		
		
		
		
		 System.out.println(flightnum);
		 
		 ticketReservation.setFlightOne(flightnum);
		 ticketReservation.setPriceForOneWay(price);
		 
		 Integer noOfSeats=ticketReservation.getNoOfSeats();
		 
		 Integer totalAmount=0;
		 
		 totalAmount=(int) (noOfSeats*price);
		 
		 ticketReservation.setTotal_Amount(totalAmount);
		 
		 
		 model.addAttribute("ticketReservation", ticketReservation);
		 
		 
		 
	 }
	 catch(Exception e){
		 e.printStackTrace();
	 }
	 
		 return "selectedFlightDetails";
		 
	 }
	 
	 @RequestMapping("cancel")
	 public String cancel(Model model){
		
		 TicketReservation ticketReservation=new TicketReservation();
		 model.addAttribute("ticketReservation",ticketReservation);
		 
		 
		 return "searchFlights";
		 
	 }
	 
	 

	 
	 
	 
	 
	 
	 
	 
	 
	
	 
}

