


import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.ars.DAO.HibernateUtil;
import com.neu.ars.pojo.Address;
import com.neu.ars.pojo.Admin;
import com.neu.ars.pojo.FlightClass;
import com.neu.ars.pojo.FlightInventory;
import com.neu.ars.pojo.Payment;
import com.neu.ars.pojo.Person;
import com.neu.ars.pojo.Routine;
import com.neu.ars.pojo.TicketReservation;
import com.neu.ars.pojo.Users;





public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		/*
		Users user = new Users();
		user.setAge(10);
		user.setContactNumber(11111);
		user.setEmail("ioop");
		user.setFavouriteDestination("swiz");
		user.setFirstName("f1");
		user.setLastName("l1");
		user.setGender("f");
		user.setHomeAirport("india");
		user.setPassword("x");
		user.setMembership_id(123);
		user.setUserName("x");
		
		
		
		Person p=new Person();
		
		p.setAge(12);
		p.setContactNumber(1234);
		p.setEmail("cvb");
		p.setFirstName("gh");
		p.setGender("f");
		p.setLastName("lll");
		p.setPassword("u");
		p.setUserName("u");
		
		
		
		
		Address add1=new Address();
		Address add2=new Address();
		
		add1.setFlatNo(10);
		add1.setStreetName("ghu");
		
	
		add2.setFlatNo(12);
		add2.setStreetName("eeer");
		
		Set<Address>add=new HashSet<Address>();
		add.add(add1);

		
		
		
		
		
p.setAdd(add); 

Set<Address> addre=new HashSet<Address>();
addre.add(add2);






//many-to -many -join table insertion manually; so this was used; if not running, remove the 2 lines below

Set<Person>list = new HashSet<Person>();


list.add(p);



//        session.save(stock);
        
		//Address ad=new Address();
		//ad.setFlatNo(10);
		//ad.setStreetName("alph");
		//ad.getPersons().add(p);
		
		Admin a=new Admin();
		a.setAge(7);
		a.setContactNumber(987);
		a.setEmail("jjj");
		a.setFirstName("ff");
		a.setLastName("lll");
		a.setGender("m");
		a.setPassword("y");
		a.setUserName("y");
		a.setRequest("req");
		a.setShift("first");
		
		
		*/
		FlightInventory fi=new FlightInventory();
		fi.setAirline("BA");
		fi.setStartAirport("Boston");
		fi.setEndAirport("India");
		
		
		
		Routine r=new Routine();
		r.setArrivalDate("jan");
		r.setDepartureDate("jun");
		r.setStartTime("9 am");
		r.setEndTime("12 am");
		r.setFlight(fi);
		
		
		FlightClass f=new FlightClass();
		f.setNoOfSeats(2);
		f.setPrice(120.0);
		f.setClassType("economy");
		f.setRoutine(r);
		
		/*TicketReservation tr=new TicketReservation();
		tr.setBooking_ref("ba123");
		tr.setArrivalDate("jan");
		tr.setBookingDate("jan");
		tr.setDepartureDate("dec");
		tr.setEndTime("12 am");
		tr.setStartTime("7 pm");
		tr.setTotal_Amount(100);
		tr.setId(1);
		tr.setNoOfSeats(1);
		tr.setTripType("round");
		tr.setStartAirport("singapore");
		tr.setEndAirport("nepal");
		tr.setClassType("economy");
		
		
		Payment pa=new Payment();
		pa.setStatus("yes");
		pa.setTransaction_Date("oct");
		
		*/
		
		
		//session.persist(user);
		//session.persist(tr);
		//session.persist(a);
		session.persist(r);
	//	session.persist(pa);
		session.persist(fi);
		session.persist(f);
	//	session.persist(p);
		//session.persist(add1);
		//session.persist(add2);


		
				
		
		t.commit();
		session.close();
		System.out.println("Success");
	}
	}

